package com.freeclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Free Client menu with galaxy-style animated toggles.
 * OFF modules: dark space panel. ON modules: moving purple/blue/pink nebula + twinkling stars.
 * Clicking a module plays a short bright "burst" flash.
 */
public final class FreeClientScreen extends Screen {
    // Space palette (ARGB)
    private static final int PANEL = 0xD90B0A1F;
    private static final int PANEL_HEADER = 0xF01A1240;
    private static final int OFF_ROW = 0xCC14122E;
    private static final int OFF_BORDER = 0xFF3A2F6B;
    private static final int TEXT = 0xFFF4F0FF;
    private static final int MUTED = 0xFFA99FD6;
    private static final int TITLE_GLOW = 0xFFC9A7FF;

    // Nebula colors the ON gradient flows through
    private static final int[] NEBULA = {
            0xFF2B0B5E, // deep violet
            0xFF5B2BD9, // purple
            0xFF2F7BFF, // cosmic blue
            0xFFE04BD6, // pink
            0xFF27D3F5, // cyan
            0xFF2B0B5E
    };

    private final Map<String, Boolean> enabled = new LinkedHashMap<>();
    private final Map<String, Long> pressedAt = new LinkedHashMap<>();
    private final List<PanelLayout> layouts = new ArrayList<>();
    private final List<RowLayout> rows = new ArrayList<>();

    private final List<ModuleGroup> groups = List.of(
            new ModuleGroup("HUD", List.of("Strength Timer", "Coordinates", "Keystrokes")),
            new ModuleGroup("Inventory", List.of("Container Counter", "Armor Status")),
            new ModuleGroup("Visuals", List.of("Potion Effects", "Clean HUD"))
    );

    public FreeClientScreen() {
        super(Text.literal("Free Client"));
        for (ModuleGroup group : groups) {
            for (String module : group.modules()) {
                enabled.put(module, false);
            }
        }
    }

    @Override
    protected void init() {
        layouts.clear();
        rows.clear();

        int gap = 12;
        int panelWidth = Math.max(150, Math.min(220, (this.width - 48 - gap * 2) / 3));
        int totalWidth = panelWidth * 3 + gap * 2;
        int startX = (this.width - totalWidth) / 2;
        int top = Math.max(50, this.height / 5);
        int panelHeight = 164;

        for (int i = 0; i < groups.size(); i++) {
            ModuleGroup group = groups.get(i);
            int x = startX + i * (panelWidth + gap);
            layouts.add(new PanelLayout(x, top, panelWidth, panelHeight, group.title()));

            int rowY = top + 47;
            for (String module : group.modules()) {
                int rx = x + 10;
                int rw = panelWidth - 20;
                // The vanilla button handles clicks; we paint the galaxy look on top of it.
                ButtonWidget button = ButtonWidget.builder(Text.empty(), widget -> {
                    enabled.put(module, !enabled.getOrDefault(module, false));
                    pressedAt.put(module, System.currentTimeMillis());
                }).dimensions(rx, rowY, rw, 24).build();
                addDrawableChild(button);
                rows.add(new RowLayout(module, rx, rowY, rw, 24, button));
                rowY += 31;
            }
        }

        int footerY = this.height - 44;
        int footerWidth = 104;
        int footerGap = 8;
        int footerStart = (this.width - (footerWidth * 2 + footerGap)) / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("All off"), button -> {
            enabled.replaceAll((name, value) -> false);
            pressedAt.clear();
        }).dimensions(footerStart, footerY, footerWidth, 24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                .dimensions(footerStart + footerWidth + footerGap, footerY, footerWidth, 24)
                .build());
    }

    /**
     * Minecraft 1.21.x allows the background blur only once per frame.
     * super.render() already calls renderBackground(), so we draw our panels here
     * instead of calling renderBackground() ourselves (that caused the crash).
     */
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        super.renderBackground(context, mouseX, mouseY, delta);
        long now = System.currentTimeMillis();

        int titleY = Math.max(14, this.height / 5 - 35);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("FREE CLIENT"), this.width / 2, titleY, TITLE_GLOW);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("1.21.11  •  Galaxy Edition"), this.width / 2, titleY + 17, MUTED);

        for (PanelLayout layout : layouts) {
            int x = layout.x();
            int y = layout.y();
            context.fill(x, y, x + layout.width(), y + layout.height(), PANEL);
            drawNebula(context, x, y, layout.width(), 30, now, 0.35f, 0.55f);
            drawStars(context, x, y, layout.width(), 30, now, layout.title().hashCode(), 6);
            context.drawText(textRenderer, Text.literal(layout.title()), x + 12, y + 11, TEXT, true);
            context.drawText(textRenderer, Text.literal("MODULES"), x + 12, y + 36, MUTED, false);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Background + panels (via renderBackground) and vanilla widgets
        super.render(context, mouseX, mouseY, delta);

        long now = System.currentTimeMillis();
        // Galaxy rows painted over the module buttons
        for (RowLayout row : rows) {
            drawModuleRow(context, row, mouseX, mouseY, now);
        }
    }

    private void drawModuleRow(DrawContext context, RowLayout row, int mouseX, int mouseY, long now) {
        int x = row.x(), y = row.y(), w = row.width(), h = row.height();
        boolean on = enabled.getOrDefault(row.module(), false);
        boolean hovered = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;

        if (on) {
            drawNebula(context, x, y, w, h, now, 1.0f, 1.0f);
            drawStars(context, x, y, w, h, now, row.module().hashCode(), 9);
            drawFrame(context, x, y, w, h, hovered ? 0xFFFFFFFF : 0xFFC9A7FF);
        } else {
            context.fill(x, y, x + w, y + h, OFF_ROW);
            if (hovered) {
                drawNebula(context, x, y, w, h, now, 0.25f, 0.6f);
            }
            drawFrame(context, x, y, w, h, hovered ? 0xFF8A6CFF : OFF_BORDER);
        }

        // Click burst: bright flash that fades over 350 ms
        Long pressed = pressedAt.get(row.module());
        if (pressed != null) {
            long age = now - pressed;
            if (age < 350) {
                int alpha = (int) (180 * (1.0 - age / 350.0));
                context.fill(x, y, x + w, y + h, (alpha << 24) | 0xFFFFFF);
            }
        }

        // Label + status pill
        context.drawText(textRenderer, Text.literal(row.module()), x + 8, y + 8, TEXT, true);
        String state = on ? "ON" : "OFF";
        int pillW = textRenderer.getWidth(state) + 8;
        int px = x + w - pillW - 6;
        context.fill(px, y + 6, px + pillW, y + h - 6, on ? 0xAAFFFFFF : 0x66000000);
        context.drawText(textRenderer, Text.literal(state), px + 4, y + 8, on ? 0xFF2B0B5E : MUTED, false);
    }

    /** Animated horizontal nebula gradient drawn as thin vertical slices. */
    private void drawNebula(DrawContext context, int x, int y, int w, int h, long now, float strength, float alphaScale) {
        double shift = (now % 6000L) / 6000.0;
        for (int i = 0; i < w; i += 2) {
            double t = ((double) i / Math.max(1, w) * 0.6 + shift) % 1.0;
            int top = sampleNebula(t);
            int bottom = sampleNebula((t + 0.18) % 1.0);
            top = withAlpha(scale(top, strength), alphaScale);
            bottom = withAlpha(scale(bottom, strength * 0.8f), alphaScale);
            context.fillGradient(x + i, y, Math.min(x + i + 2, x + w), y + h, top, bottom);
        }
    }

    /** Twinkling 1px stars with fixed positions per element. */
    private void drawStars(DrawContext context, int x, int y, int w, int h, long now, int seed, int count) {
        java.util.Random random = new java.util.Random(seed);
        for (int i = 0; i < count; i++) {
            int sx = x + 2 + random.nextInt(Math.max(1, w - 4));
            int sy = y + 2 + random.nextInt(Math.max(1, h - 4));
            double phase = random.nextDouble() * Math.PI * 2;
            double twinkle = 0.5 + 0.5 * Math.sin(now / 280.0 + phase);
            int alpha = (int) (60 + 195 * twinkle);
            context.fill(sx, sy, sx + 1, sy + 1, (alpha << 24) | 0xFFFFFF);
        }
    }

    private void drawFrame(DrawContext context, int x, int y, int w, int h, int color) {
        context.fill(x, y, x + w, y + 1, color);
        context.fill(x, y + h - 1, x + w, y + h, color);
        context.fill(x, y, x + 1, y + h, color);
        context.fill(x + w - 1, y, x + w, y + h, color);
    }

    private static int sampleNebula(double t) {
        double pos = t * (NEBULA.length - 1);
        int i = (int) Math.floor(pos);
        double f = pos - i;
        return lerp(NEBULA[i], NEBULA[Math.min(i + 1, NEBULA.length - 1)], f);
    }

    private static int lerp(int a, int b, double f) {
        int r = (int) (((a >> 16) & 0xFF) + (((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * f);
        int g = (int) (((a >> 8) & 0xFF) + (((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * f);
        int bl = (int) ((a & 0xFF) + ((b & 0xFF) - (a & 0xFF)) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int scale(int color, float s) {
        int r = Math.min(255, (int) (((color >> 16) & 0xFF) * s));
        int g = Math.min(255, (int) (((color >> 8) & 0xFF) * s));
        int b = Math.min(255, (int) ((color & 0xFF) * s));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int withAlpha(int color, float alphaScale) {
        int a = Math.max(0, Math.min(255, (int) (255 * alphaScale)));
        return (a << 24) | (color & 0xFFFFFF);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private record ModuleGroup(String title, List<String> modules) { }
    private record PanelLayout(int x, int y, int width, int height, String title) { }
    private record RowLayout(String module, int x, int y, int width, int height, ButtonWidget button) { }
}
