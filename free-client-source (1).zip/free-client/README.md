# Free Client 0.1 Beta (Minecraft Java 1.21.11, Fabric)

Fair-play, client-side menu with galaxy-style toggles. Open with Right Shift.

## Build on GitHub (phone friendly)
1. Upload `free-client-source.zip` to the root of your GitHub repo.
2. Create `.github/workflows/build.yml` with the provided workflow.
3. GitHub Actions builds the mod and publishes `free-client0.1Beta.jar` under Releases (tag `v0.1-beta`).

Requires Fabric Loader + Fabric API for 1.21.11. Never rename the source ZIP to .jar.
